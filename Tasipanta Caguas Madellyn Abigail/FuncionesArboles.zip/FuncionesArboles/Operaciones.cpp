#include <iostream>
#include <cstdlib>
using namespace std;

class Nodo {
public:
    int dato;
    Nodo* izq;
    Nodo* der;
    
    Nodo(int valor) {
        dato = valor;
        izq = NULL;
        der = NULL;
    }
};

class ArbolBinario {
private:
    Nodo* raiz;
    
    Nodo* insertar(Nodo* nodo, int valor) {
        if (nodo == NULL) {
            return new Nodo(valor);
        }
        
        if (valor < nodo->dato) {
            nodo->izq = insertar(nodo->izq, valor);
        } else if (valor > nodo->dato) {
            nodo->der = insertar(nodo->der, valor);
        }
        
        return nodo;
    }
    
    Nodo* buscar(Nodo* nodo, int valor) {
        if (nodo == NULL || nodo->dato == valor) {
            return nodo;
        }
        
        if (valor < nodo->dato) {
            return buscar(nodo->izq, valor);
        }
        
        return buscar(nodo->der, valor);
    }
    
    Nodo* encontrarMinimo(Nodo* nodo) {
        while (nodo->izq != NULL) {
            nodo = nodo->izq;
        }
        return nodo;
    }
    
    Nodo* eliminar(Nodo* nodo, int valor) {
        if (nodo == NULL) {
            return nodo;
        }
        
        if (valor < nodo->dato) {
            nodo->izq = eliminar(nodo->izq, valor);
        } else if (valor > nodo->dato) {
            nodo->der = eliminar(nodo->der, valor);
        } else {
            // Nodo encontrado
            if (nodo->izq == NULL) {
                Nodo* temp = nodo->der;
                delete nodo;
                return temp;
            } else if (nodo->der == NULL) {
                Nodo* temp = nodo->izq;
                delete nodo;
                return temp;
            }
            
            // Nodo con dos hijos
            Nodo* temp = encontrarMinimo(nodo->der);
            nodo->dato = temp->dato;
            nodo->der = eliminar(nodo->der, temp->dato);
        }
        
        return nodo;
    }
    
    void imprimirArbolRecursivo(Nodo* nodo, int espacio) {
        if (nodo == NULL) {
            return;
        }
        
        espacio += 10;
        
        imprimirArbolRecursivo(nodo->der, espacio);
        
        cout << "\n";
        for (int i = 10; i < espacio; i++) {
            cout << " ";
        }
        cout << nodo->dato << "\n";
        
        imprimirArbolRecursivo(nodo->izq, espacio);
    }
    
    void imprimirEnOrden(Nodo* nodo) {
        if (nodo != NULL) {
            imprimirEnOrden(nodo->izq);
            cout << nodo->dato << " ";
            imprimirEnOrden(nodo->der);
        }
    }
    
    void imprimirPreOrden(Nodo* nodo) {
        if (nodo != NULL) {
            cout << nodo->dato << " ";
            imprimirPreOrden(nodo->izq);
            imprimirPreOrden(nodo->der);
        }
    }
    
public:
    ArbolBinario() {
        raiz = NULL;
    }
    
    void insertarValor(int valor) {
        raiz = insertar(raiz, valor);
    }
    
    bool buscarValor(int valor) {
        return buscar(raiz, valor) != NULL;
    }
    
    void eliminarValor(int valor) {
        raiz = eliminar(raiz, valor);
    }
    
    void mostrarArbol() {
        if (raiz == NULL) {
            cout << "\n  El arbol esta vacio\n";
            return;
        }
        
        cout << "\n  Representacion del arbol (derecha arriba, izquierda abajo):\n";
        imprimirArbolRecursivo(raiz, 0);
        
        cout << "\n  Recorrido en orden: ";
        imprimirEnOrden(raiz);
        
        cout << "\n  Recorrido preorden: ";
        imprimirPreOrden(raiz);
        cout << "\n";
    }
};

void limpiarPantalla() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

void pausa() {
    cout << "\n  Presione Enter para continuar...";
    cin.ignore();
    cin.get();
}

int main() {
    ArbolBinario arbol;
    int opcion, valor;
    
    do {
        limpiarPantalla();
        
        cout << "\n  ========================================\n";
        cout << "       ARBOL BINARIO DE BUSQUEDA\n";
        cout << "  ========================================\n\n";
        
        arbol.mostrarArbol();
        
        cout << "\n  ========================================\n";
        cout << "  1. Insertar valor\n";
        cout << "  2. Buscar valor\n";
        cout << "  3. Eliminar valor\n";
        cout << "  4. Salir\n";
        cout << "  ========================================\n";
        cout << "\n  Seleccione una opcion: ";
        cin >> opcion;
        
        switch(opcion) {
            case 1:
                cout << "\n  Ingrese el valor a insertar: ";
                cin >> valor;
                arbol.insertarValor(valor);
                cout << "\n  Valor " << valor << " insertado correctamente!";
                pausa();
                break;
                
            case 2:
                cout << "\n  Ingrese el valor a buscar: ";
                cin >> valor;
                if (arbol.buscarValor(valor)) {
                    cout << "\n  El valor " << valor << " SI existe en el arbol!";
                } else {
                    cout << "\n  El valor " << valor << " NO existe en el arbol!";
                }
                pausa();
                break;
                
            case 3:
                cout << "\n  Ingrese el valor a eliminar: ";
                cin >> valor;
                if (arbol.buscarValor(valor)) {
                    arbol.eliminarValor(valor);
                    cout << "\n  Valor " << valor << " eliminado correctamente!";
                } else {
                    cout << "\n  El valor " << valor << " no existe en el arbol!";
                }
                pausa();
                break;
                
            case 4:
                cout << "\n  Saliendo del programa...\n\n";
                break;
                
            default:
                cout << "\n  Opcion invalida!";
                pausa();
        }
        
    } while(opcion != 4);
    
    return 0;
}