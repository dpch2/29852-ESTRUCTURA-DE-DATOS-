#include <iostream>
#include "ArbolBase.h"
#include "ArbolBinario.h"
#include "ArbolAVL.h"
#include "Utils.h"
using namespace std;

int main() {
    ArbolBase* arbol = NULL;
    int tipoArbol = 1;
    int opcion, valor;

    cout << "============================================\n";
    cout << "   SIMULADOR DE ARBOLES AVL Y BINARIOS\n";
    cout << "============================================\n";
    cout << "\n1. Arbol AVL\n";
    cout << "2. Arbol Binario\n";
    tipoArbol = leerOpcionMenu("\nOpcion: ", 1, 2);

    if (tipoArbol == 1) {
        arbol = new ArbolAVL();
        cout << "\nArbol AVL seleccionado\n";
    } else {
        arbol = new ArbolBinario();
        cout << "\nArbol Binario seleccionado\n";
    }

    pausar();

    do {
        limpiarPantalla();
        cout << "\nTIPO: " << (tipoArbol == 1 ? "AVL" : "BINARIO") << "\n";
        mostrarMenu();
        opcion = leerOpcionMenu("", 1, 9);

        switch (opcion) {
        case 1:
            valor = leerNumeroEntero("\nValor a insertar: ");
            cout << "Los nodos izquierdos (menores) se muestran con /-- y los derechos (mayores) con \\--\n";
            arbol->insertar(valor);
            arbol->imprimir();
            pausar();
            break;
        case 2:
            if (!arbol->estaVacio()) {
                valor = leerNumeroEntero("\nValor a eliminar: ");
                arbol->eliminar(valor);
                arbol->imprimir();
            } else {
                cout << "\nArbol vacio\n";
            }
            pausar();
            break;
        case 3:
            if (!arbol->estaVacio()) {
                valor = leerNumeroEntero("\nValor a buscar: ");
                arbol->buscar(valor);
            } else {
                cout << "\nArbol vacio\n";
            }
            pausar();
            break;
        case 4:
            arbol->imprimir();
            pausar();
            break;
        case 5:
            arbol->inorden();
            pausar();
            break;
        case 6:
            arbol->preorden();
            pausar();
            break;
        case 7:
            arbol->postorden();
            pausar();
            break;
        case 8:
            delete arbol;
            tipoArbol = leerOpcionMenu("\n1. AVL\n2. Binario\nOpcion: ", 1, 2);
            if (tipoArbol == 1)
                arbol = new ArbolAVL();
            else
                arbol = new ArbolBinario();
            pausar();
            break;
        case 9:
            cout << "\nGracias!\n";
            break;
        default:
            cout << "\nOpcion invalida\n";
            pausar();
        }
    } while (opcion != 9);

    delete arbol;
    return 0;
}