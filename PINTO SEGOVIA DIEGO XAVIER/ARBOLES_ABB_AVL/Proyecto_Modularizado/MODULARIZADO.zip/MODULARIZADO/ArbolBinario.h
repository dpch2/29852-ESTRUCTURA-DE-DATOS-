#ifndef ARBOL_BINARIO_H
#define ARBOL_BINARIO_H

#include "ArbolBase.h"

class ArbolBinario : public ArbolBase {
private:
    Nodo* insertarRec(Nodo* nodo, int valor);
    Nodo* eliminarRec(Nodo* nodo, int valor);
    bool buscarRec(Nodo* nodo, int valor);

public:
    void insertar(int valor) override;
    void eliminar(int valor) override;
    bool buscar(int valor) override;
};

#endif