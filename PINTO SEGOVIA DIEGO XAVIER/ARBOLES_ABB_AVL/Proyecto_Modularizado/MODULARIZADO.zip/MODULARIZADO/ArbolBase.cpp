#include "ArbolBase.h"
#include <iostream>
using namespace std;

ArbolBase::ArbolBase() {
    raiz = NULL;
}

void ArbolBase::imprimirNodoVertical(Nodo* nodo, string espacios, bool esDerecho) {
    if (nodo != NULL) {
        cout << espacios;
        if (esDerecho) {
            cout << "\\-- ";
            espacios += "    ";
        } else {
            cout << "/-- ";
            espacios += "|   ";
        }
        cout << nodo->valor << endl;
        
        if (nodo->izquierdo != NULL || nodo->derecho != NULL) {
            if (nodo->izquierdo != NULL)
                imprimirNodoVertical(nodo->izquierdo, espacios, false);
            else {
                cout << espacios << "/-- [vacio]" << endl;
            }
            
            if (nodo->derecho != NULL)
                imprimirNodoVertical(nodo->derecho, espacios, true);
            else {
                cout << espacios << "\\-- [vacio]" << endl;
            }
        }
    }
}

void ArbolBase::imprimirVertical() {
    if (raiz == NULL) {
        cout << "\n[Arbol vacio]\n";
        return;
    }
    cout << "\n";
    cout << raiz->valor << endl;
    if (raiz->izquierdo != NULL)
        imprimirNodoVertical(raiz->izquierdo, "", false);
    else
        cout << "/-- [vacio]" << endl;
        
    if (raiz->derecho != NULL)
        imprimirNodoVertical(raiz->derecho, "", true);
    else
        cout << "\\-- [vacio]" << endl;
    cout << "\n";
}

Nodo* ArbolBase::encontrarMaximo(Nodo* nodo) {
    while (nodo->derecho != NULL) {
        nodo = nodo->derecho;
    }
    return nodo;
}

Nodo* ArbolBase::encontrarMinimo(Nodo* nodo) {
    while (nodo->izquierdo != NULL) {
        nodo = nodo->izquierdo;
    }
    return nodo;
}

void ArbolBase::inordenRec(Nodo* nodo) {
    if (nodo != NULL) {
        inordenRec(nodo->izquierdo);
        cout << nodo->valor << " ";
        inordenRec(nodo->derecho);
    }
}

void ArbolBase::preordenRec(Nodo* nodo) {
    if (nodo != NULL) {
        cout << nodo->valor << " ";
        preordenRec(nodo->izquierdo);
        preordenRec(nodo->derecho);
    }
}

void ArbolBase::postordenRec(Nodo* nodo) {
    if (nodo != NULL) {
        postordenRec(nodo->izquierdo);
        postordenRec(nodo->derecho);
        cout << nodo->valor << " ";
    }
}

void ArbolBase::imprimir() {
    if (raiz == NULL) {
        cout << "\n[Arbol vacio]\n";
        return;
    }
    imprimirVertical();
}

void ArbolBase::inorden() {
    cout << "\nRecorrido INORDEN: ";
    if (raiz == NULL) {
        cout << "[Arbol vacio]";
    } else {
        inordenRec(raiz);
    }
    cout << "\n";
}

void ArbolBase::preorden() {
    cout << "\nRecorrido PREORDEN: ";
    if (raiz == NULL) {
        cout << "[Arbol vacio]";
    } else {
        preordenRec(raiz);
    }
    cout << "\n";
}

void ArbolBase::postorden() {
    cout << "\nRecorrido POSTORDEN: ";
    if (raiz == NULL) {
        cout << "[Arbol vacio]";
    } else {
        postordenRec(raiz);
    }
    cout << "\n";
}

bool ArbolBase::estaVacio() {
    return raiz == NULL;
}