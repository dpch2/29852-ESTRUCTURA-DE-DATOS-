#ifndef ARBOL_BASE_H
#define ARBOL_BASE_H

#include <iostream>
#include <string>
#include "Nodo.h"
using namespace std;

class ArbolBase {
protected:
    Nodo* raiz;

    void imprimirNodoVertical(Nodo* nodo, string espacios, bool esDerecho);
    void imprimirVertical();
    Nodo* encontrarMaximo(Nodo* nodo);
    Nodo* encontrarMinimo(Nodo* nodo);
    void inordenRec(Nodo* nodo);
    void preordenRec(Nodo* nodo);
    void postordenRec(Nodo* nodo);

public:
    ArbolBase();
    virtual void insertar(int valor) = 0;
    virtual void eliminar(int valor) = 0;
    virtual bool buscar(int valor) = 0;
    virtual ~ArbolBase() {}

    void imprimir();
    void inorden();
    void preorden();
    void postorden();
    bool estaVacio();
};

#endif