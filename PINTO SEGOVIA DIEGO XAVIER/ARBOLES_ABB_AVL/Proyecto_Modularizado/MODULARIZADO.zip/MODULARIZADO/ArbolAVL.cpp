#include "ArbolAVL.h"
#include <iostream>
using namespace std;

int ArbolAVL::obtenerAltura(Nodo* nodo) {
    if (nodo == NULL) return 0;
    return nodo->altura;
}

int ArbolAVL::obtenerBalance(Nodo* nodo) {
    if (nodo == NULL) return 0;
    return obtenerAltura(nodo->izquierdo) - obtenerAltura(nodo->derecho);
}

void ArbolAVL::actualizarAltura(Nodo* nodo) {
    int altIzq = obtenerAltura(nodo->izquierdo);
    int altDer = obtenerAltura(nodo->derecho);
    nodo->altura = 1 + (altIzq > altDer ? altIzq : altDer);
}

Nodo* ArbolAVL::rotarDerecha(Nodo* y) {
    cout << "   [ROTACION DERECHA en nodo " << y->valor << "]\n";
    Nodo* x = y->izquierdo;
    Nodo* T2 = x->derecho;
    x->derecho = y;
    y->izquierdo = T2;
    actualizarAltura(y);
    actualizarAltura(x);
    return x;
}

Nodo* ArbolAVL::rotarIzquierda(Nodo* x) {
    cout << "   [ROTACION IZQUIERDA en nodo " << x->valor << "]\n";
    Nodo* y = x->derecho;
    Nodo* T2 = y->izquierdo;
    y->izquierdo = x;
    x->derecho = T2;
    actualizarAltura(x);
    actualizarAltura(y);
    return y;
}

Nodo* ArbolAVL::insertarRec(Nodo* nodo, int valor) {
    if (nodo == NULL) {
        cout << "   Insertando " << valor << "\n";
        return new Nodo(valor);
    }

    if (valor < nodo->valor) {
        cout << "   " << valor << " < " << nodo->valor << " -> Izquierda\n";
        nodo->izquierdo = insertarRec(nodo->izquierdo, valor);
    } else if (valor > nodo->valor) {
        cout << "   " << valor << " > " << nodo->valor << " -> Derecha\n";
        nodo->derecho = insertarRec(nodo->derecho, valor);
    } else {
        // DUPLICADO: Regla especial - derecha→izquierda
        cout << "   " << valor << " == " << nodo->valor << " (DUPLICADO)\n";
        if (nodo->derecho == NULL) {
            cout << "   Insertando duplicado a la derecha (espacio libre)\n";
            nodo->derecho = new Nodo(valor);
        } else if (nodo->derecho->izquierdo == NULL) {
            cout << "   Insertando duplicado en derecha->izquierda\n";
            nodo->derecho->izquierdo = new Nodo(valor);
        } else {
            cout << "   Derecha->izquierda ocupado, buscando a la izquierda de ese nodo\n";
            nodo->derecho->izquierdo = insertarRec(nodo->derecho->izquierdo, valor);
        }
        // No necesita balanceo al insertar duplicado de esta forma especial
        return nodo;
    }

    actualizarAltura(nodo);
    int balance = obtenerBalance(nodo);
    cout << "   Balance en nodo " << nodo->valor << ": " << balance << "\n";

    if (balance > 1 && valor < nodo->izquierdo->valor) {
        cout << "   Desbalance IZQUIERDA-IZQUIERDA\n";
        return rotarDerecha(nodo);
    }
    if (balance < -1 && valor > nodo->derecho->valor) {
        cout << "   Desbalance DERECHA-DERECHA\n";
        return rotarIzquierda(nodo);
    }
    if (balance > 1 && valor > nodo->izquierdo->valor) {
        cout << "   Desbalance IZQUIERDA-DERECHA\n";
        nodo->izquierdo = rotarIzquierda(nodo->izquierdo);
        return rotarDerecha(nodo);
    }
    if (balance < -1 && valor < nodo->derecho->valor) {
        cout << "   Desbalance DERECHA-IZQUIERDA\n";
        nodo->derecho = rotarDerecha(nodo->derecho);
        return rotarIzquierda(nodo);
    }
    return nodo;
}

Nodo* ArbolAVL::eliminarRec(Nodo* nodo, int valor) {
    if (nodo == NULL) {
        cout << "   Valor no encontrado\n";
        return NULL;
    }

    if (valor < nodo->valor) {
        nodo->izquierdo = eliminarRec(nodo->izquierdo, valor);
    } else if (valor > nodo->valor) {
        nodo->derecho = eliminarRec(nodo->derecho, valor);
    } else {
        // Nodo encontrado
        if (nodo->izquierdo == NULL || nodo->derecho == NULL) {
            Nodo* temp = nodo->izquierdo ? nodo->izquierdo : nodo->derecho;
            if (temp == NULL) {
                temp = nodo;
                nodo = NULL;
            } else {
                *nodo = *temp;
            }
            delete temp;
        } else {
            // CORREGIDO: Usa el predecesor (mayor del subárbol izquierdo)
            Nodo* predecesor = encontrarMaximo(nodo->izquierdo);
            cout << "   Reemplazando con predecesor " << predecesor->valor << " (mayor del subarbol izquierdo)\n";
            nodo->valor = predecesor->valor;
            nodo->izquierdo = eliminarRec(nodo->izquierdo, predecesor->valor);
        }
    }

    if (nodo == NULL) return nodo;

    actualizarAltura(nodo);
    int balance = obtenerBalance(nodo);

    if (balance > 1 && obtenerBalance(nodo->izquierdo) >= 0)
        return rotarDerecha(nodo);
    if (balance > 1 && obtenerBalance(nodo->izquierdo) < 0) {
        nodo->izquierdo = rotarIzquierda(nodo->izquierdo);
        return rotarDerecha(nodo);
    }
    if (balance < -1 && obtenerBalance(nodo->derecho) <= 0)
        return rotarIzquierda(nodo);
    if (balance < -1 && obtenerBalance(nodo->derecho) > 0) {
        nodo->derecho = rotarDerecha(nodo->derecho);
        return rotarIzquierda(nodo);
    }
    return nodo;
}

bool ArbolAVL::buscarRec(Nodo* nodo, int valor) {
    if (nodo == NULL) {
        cout << "   Valor no encontrado\n";
        return false;
    }
    if (valor == nodo->valor) {
        cout << "   Valor encontrado!\n";
        return true;
    }
    if (valor < nodo->valor)
        return buscarRec(nodo->izquierdo, valor);
    else
        return buscarRec(nodo->derecho, valor);
}

void ArbolAVL::insertar(int valor) {
    cout << "\nINSERTANDO " << valor << " EN ARBOL AVL:\n";
    raiz = insertarRec(raiz, valor);
}

void ArbolAVL::eliminar(int valor) {
    cout << "\nELIMINANDO " << valor << " DEL ARBOL AVL:\n";
    raiz = eliminarRec(raiz, valor);
}

bool ArbolAVL::buscar(int valor) {
    cout << "\nBUSCANDO " << valor << " EN ARBOL AVL:\n";
    return buscarRec(raiz, valor);
}