#include "Utils.h"
#include <iostream>
#include <cstdlib>
using namespace std;

int leerNumeroEntero(const string& mensaje) {
    string numero = "";
    char tecla;
    
    cout << mensaje;
    
    while (true) {
        #ifdef _WIN32
            tecla = _getch(); // Captura tecla sin mostrarla
        #else
            tecla = getchar();
        #endif
        
        // Si es Enter y tenemos al menos un dígito
        if (tecla == '\r' || tecla == '\n') {
            if (!numero.empty()) {
                break;
            }
            continue;
        }
        
        // Si es Backspace
        if (tecla == '\b' || tecla == 127) {
            if (!numero.empty()) {
                numero.pop_back();
                cout << "\b \b"; // Borra el carácter en pantalla
            }
            continue;
        }
        
        // Solo acepta dígitos (el signo menos se ignora completamente)
        if (isdigit(tecla)) {
            numero += tecla;
            cout << tecla; // Muestra el dígito
        }
        // Cualquier otra tecla (incluyendo -) es ignorada (no se muestra nada)
    }
    
    cout << endl;
    
    // Convertir a entero
    int resultado = 0;
    if (!numero.empty()) {
        resultado = stoi(numero);
    }
    
    return resultado;
}

int leerOpcionMenu(const string& mensaje, int opcionMin, int opcionMax) {
    int opcion;
    
    while (true) {
        opcion = leerNumeroEntero(mensaje);
        
        if (opcion >= opcionMin && opcion <= opcionMax) {
            return opcion;
        } else {
            cout << "\nError: Opcion invalida. Ingrese un numero entre " << opcionMin << " y " << opcionMax << ".\n";
        }
    }
}

void limpiarPantalla() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

void pausar() {
    cout << "\nPresione Enter para continuar...";
    cin.ignore();
    cin.get();
}

void mostrarMenu() {
    cout << "\n============================================\n";
    cout << "   SIMULADOR DE ARBOLES AVL Y BINARIOS\n";
    cout << "============================================\n";
    cout << "1. Insertar valor\n";
    cout << "2. Eliminar valor\n";
    cout << "3. Buscar valor\n";
    cout << "4. Imprimir arbol (estructura)\n";
    cout << "5. Recorrido Inorden\n";
    cout << "6. Recorrido Preorden\n";
    cout << "7. Recorrido Postorden\n";
    cout << "8. Cambiar tipo de arbol\n";
    cout << "9. Salir\n";
    cout << "\nOpcion: ";
}