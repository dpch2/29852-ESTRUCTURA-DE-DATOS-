#ifndef VALIDACIONES_HPP

#define VALIDACIONES_HPP

#include <string>
#include <cctype>
using namespace std;

class Validaciones {
public:
    // Validacion de cedula ecuatoriana
    static bool cedulaValida(const string& cedula) {
        if (cedula.length() != 10) return false;
        
        // Verificar que todos sean digitos
        for (char c : cedula) {
            if (!isdigit(c)) return false;
        }
        
        // Validar provincia (primeros 2 digitos)
        int provincia = stoi(cedula.substr(0, 2));
        if (provincia < 1 || provincia > 24) return false;
        
        // Algoritmo de validacion de cedula ecuatoriana
        int suma = 0;
        int digito;
        for (int i = 0; i < 9; i++) {
            digito = cedula[i] - '0';
            if (i % 2 == 0) {
                digito *= 2;
                if (digito > 9) digito -= 9;
            }
            suma += digito;
        }
        
        int ultimoDigito = cedula[9] - '0';
        int digitoVerificador = (suma % 10 == 0) ? 0 : 10 - (suma % 10);
        
        return ultimoDigito == digitoVerificador;
    }
    
    // Validacion de fecha DD/MM/AAAA
    static bool fechaValida(const string& fecha) {
        if (fecha.length() != 10) return false;
        if (fecha[2] != '/' || fecha[5] != '/') return false;
        
        for (int i = 0; i < 10; i++) {
            if (i != 2 && i != 5) {
                if (!isdigit(fecha[i])) return false;
            }
        }
        
        int dia = stoi(fecha.substr(0, 2));
        int mes = stoi(fecha.substr(3, 2));
        int anio = stoi(fecha.substr(6, 4));
        
        if (mes < 1 || mes > 12) return false;
        if (dia < 1 || dia > 31) return false;
        if (anio < 2000 || anio > 2100) return false;
        
        // Validacion de dias por mes
        int diasPorMes[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        
        // Anio bisiesto
        if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0)) {
            diasPorMes[1] = 29;
        }
        
        if (dia > diasPorMes[mes - 1]) return false;
        
        return true;
    }
    
    // Validacion de hora HH:MM
    static bool horaValida(const string& hora) {
        if (hora.length() != 5) return false;
        if (hora[2] != ':') return false;
        
        for (int i = 0; i < 5; i++) {
            if (i != 2) {
                if (!isdigit(hora[i])) return false;
            }
        }
        
        int hh = stoi(hora.substr(0, 2));
        int mm = stoi(hora.substr(3, 2));
        
        if (hh < 0 || hh > 23) return false;
        if (mm < 0 || mm > 59) return false;
        
        return true;
    }
    
    // Validar que sea un numero
    static bool esNumero(const string& str) {
        if (str.empty()) return false;
        for (char c : str) {
            if (!isdigit(c)) return false;
        }
        return true;
    }
    
    // Validar que el asiento este en rango
    static bool asientoEnRango(int fila, int columna, int maxFilas, int maxColumnas) {
        return (fila >= 0 && fila < maxFilas && columna >= 0 && columna < maxColumnas);
    }
    
    // Comparar fechas (retorna: -1 si fecha1 < fecha2, 0 si iguales, 1 si fecha1 > fecha2)
    static int compararFechas(const string& fecha1, const string& fecha2) {
        int dia1 = stoi(fecha1.substr(0, 2));
        int mes1 = stoi(fecha1.substr(3, 2));
        int anio1 = stoi(fecha1.substr(6, 4));
        
        int dia2 = stoi(fecha2.substr(0, 2));
        int mes2 = stoi(fecha2.substr(3, 2));
        int anio2 = stoi(fecha2.substr(6, 4));
        
        if (anio1 != anio2) return (anio1 < anio2) ? -1 : 1;
        if (mes1 != mes2) return (mes1 < mes2) ? -1 : 1;
        if (dia1 != dia2) return (dia1 < dia2) ? -1 : 1;
        return 0;
    }
    
    // Comparar horas (retorna: -1 si hora1 < hora2, 0 si iguales, 1 si hora1 > hora2)
    static int compararHoras(const string& hora1, const string& hora2) {
        int hh1 = stoi(hora1.substr(0, 2));
        int mm1 = stoi(hora1.substr(3, 2));
        
        int hh2 = stoi(hora2.substr(0, 2));
        int mm2 = stoi(hora2.substr(3, 2));
        
        if (hh1 != hh2) return (hh1 < hh2) ? -1 : 1;
        if (mm1 != mm2) return (mm1 < mm2) ? -1 : 1;
        return 0;
    }
};
#endif