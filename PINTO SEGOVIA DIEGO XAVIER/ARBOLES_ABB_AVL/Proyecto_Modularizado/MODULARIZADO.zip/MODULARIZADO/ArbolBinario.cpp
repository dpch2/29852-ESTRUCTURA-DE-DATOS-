#include "ArbolBinario.h"
#include <iostream>
using namespace std;

Nodo* ArbolBinario::insertarRec(Nodo* nodo, int valor) {
    if (nodo == NULL) {
        cout << "   Insertando " << valor << " como nuevo nodo\n";
        return new Nodo(valor);
    }

    if (valor < nodo->valor) {
        cout << "   " << valor << " < " << nodo->valor << " -> Ir a la izquierda\n";
        nodo->izquierdo = insertarRec(nodo->izquierdo, valor);
    } else if (valor > nodo->valor) {
        cout << "   " << valor << " > " << nodo->valor << " -> Ir a la derecha\n";
        nodo->derecho = insertarRec(nodo->derecho, valor);
    } else {
        // DUPLICADO: Regla especial - derecha→izquierda
        cout << "   " << valor << " == " << nodo->valor << " (DUPLICADO)\n";
        if (nodo->derecho == NULL) {
            cout << "   Insertando duplicado a la derecha (espacio libre)\n";
            nodo->derecho = new Nodo(valor);
        } else if (nodo->derecho->izquierdo == NULL) {
            cout << "   Insertando duplicado en derecha->izquierda\n";
            nodo->derecho->izquierdo = new Nodo(valor);
        } else {
            cout << "   Derecha->izquierda ocupado, buscando a la izquierda de ese nodo\n";
            nodo->derecho->izquierdo = insertarRec(nodo->derecho->izquierdo, valor);
        }
    }
    return nodo;
}

Nodo* ArbolBinario::eliminarRec(Nodo* nodo, int valor) {
    if (nodo == NULL) {
        cout << "   Valor " << valor << " no encontrado\n";
        return NULL;
    }

    if (valor < nodo->valor) {
        cout << "   Buscando en subarbol izquierdo\n";
        nodo->izquierdo = eliminarRec(nodo->izquierdo, valor);
    } else if (valor > nodo->valor) {
        cout << "   Buscando en subarbol derecho\n";
        nodo->derecho = eliminarRec(nodo->derecho, valor);
    } else {
        // Nodo encontrado
        if (nodo->izquierdo == NULL && nodo->derecho == NULL) {
            cout << "   Eliminando nodo hoja\n";
            delete nodo;
            return NULL;
        }
        if (nodo->izquierdo == NULL) {
            cout << "   Nodo con un hijo (derecho)\n";
            Nodo* temp = nodo->derecho;
            delete nodo;
            return temp;
        }
        if (nodo->derecho == NULL) {
            cout << "   Nodo con un hijo (izquierdo)\n";
            Nodo* temp = nodo->izquierdo;
            delete nodo;
            return temp;
        }
        // CORREGIDO: Usa el predecesor (mayor del subárbol izquierdo)
        Nodo* predecesor = encontrarMaximo(nodo->izquierdo);
        cout << "   Reemplazando con predecesor " << predecesor->valor << " (mayor del subarbol izquierdo)\n";
        nodo->valor = predecesor->valor;
        nodo->izquierdo = eliminarRec(nodo->izquierdo, predecesor->valor);
    }
    return nodo;
}

bool ArbolBinario::buscarRec(Nodo* nodo, int valor) {
    if (nodo == NULL) {
        cout << "   Valor no encontrado\n";
        return false;
    }
    if (valor == nodo->valor) {
        cout << "   Valor encontrado!\n";
        return true;
    }
    if (valor < nodo->valor) {
        cout << "   Buscar a la izquierda\n";
        return buscarRec(nodo->izquierdo, valor);
    } else {
        cout << "   Buscar a la derecha\n";
        return buscarRec(nodo->derecho, valor);
    }
}

void ArbolBinario::insertar(int valor) {
    cout << "\nINSERTANDO " << valor << " EN ARBOL BINARIO:\n";
    raiz = insertarRec(raiz, valor);
}

void ArbolBinario::eliminar(int valor) {
    cout << "\nELIMINANDO " << valor << " DEL ARBOL BINARIO:\n";
    raiz = eliminarRec(raiz, valor);
}

bool ArbolBinario::buscar(int valor) {
    cout << "\nBUSCANDO " << valor << " EN ARBOL BINARIO:\n";
    return buscarRec(raiz, valor);
}