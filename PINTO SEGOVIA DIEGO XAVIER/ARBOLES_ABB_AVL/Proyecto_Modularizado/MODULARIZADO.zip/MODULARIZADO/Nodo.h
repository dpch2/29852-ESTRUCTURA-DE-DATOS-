#ifndef NODO_H
#define NODO_H

class Nodo {
public:
    int valor;
    Nodo* izquierdo;
    Nodo* derecho;
    int altura;

    Nodo(int val) {
        valor = val;
        izquierdo = NULL;
        derecho = NULL;
        altura = 1;
    }
};

#endif