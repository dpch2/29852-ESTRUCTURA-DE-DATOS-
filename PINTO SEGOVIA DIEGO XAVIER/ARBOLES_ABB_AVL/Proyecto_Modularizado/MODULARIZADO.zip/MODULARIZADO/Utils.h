#ifndef UTILS_H
#define UTILS_H

#include <iostream>
#include <string>
#include <limits>
#ifdef _WIN32
#include <conio.h>
#else
#include <termios.h>
#include <unistd.h>
#endif
using namespace std;

// Función para leer solo números tecla por tecla
int leerNumeroEntero(const string& mensaje);

// Función para leer opciones de menú con validación específica
int leerOpcionMenu(const string& mensaje, int opcionMin, int opcionMax);

// Función para limpiar pantalla
void limpiarPantalla();

// Función para pausar
void pausar();

// Función para mostrar el menú
void mostrarMenu();

#endif